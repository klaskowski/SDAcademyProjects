public class Main {
    public static void main(String[] args) {
        FileUtils utils = new FileUtils();
        utils.readFile2();
        utils.displayMovieList();
    }
}
